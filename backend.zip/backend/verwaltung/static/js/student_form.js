$(document).ready( function () {
    // adds event to get the form for adding new students
    $(".add").on("click", function () {
        $.ajax({
        type: "POST",
        url: "get_form",
        data:{"type": "s"},
        success: function (response) {
            document.getElementById("student-info").innerHTML = response;
        },
        error: function () {
            alert("ERROR: Sending request failed :(");
        }
    })});

    // Collecting and turning all the data from the form in to a Json format
    // and sending an ajax request
    $("#student-info").on("click", "#submit", function () {
        var formData = {};
        
        $(".form-item-group .form-item input, .form-item-group .form-item select").each(function () {
            var fieldName = $(this).attr("name");
            var fieldValue = $(this).val();
           
                // Sorting out uncheckted check boxes
                if ($(this).is(":checkbox")) {
                    if ($(this).is(":checked")){
                        if (!formData[fieldName]) {
                            formData[fieldName] = [];
                        }
                        formData[fieldName].push(fieldValue);
                    }
                } else {
                    // assign the value directly
                    formData[fieldName] = fieldValue;
                }
            }
        );

        $.ajax({
            type: "POST",
            url: "addStudent",
            data: formData,
            dataType: "json",
            success: function (response) {
                alert(String(response.message));
                if(response.success){
                    location.reload()
                }
            },
            error: function (response) {
                alert("ERROR: Sending request failed :(");
            }
        });
    });

    // Adding events to to checkboxes to get teachers that teach a sirten instrument
    $("#student-info").on("click", ".inst",function () {
        if($(this).is(":checked")){
            var data = {"id": $(this).val() };
            $.ajax({
                type: "POST",
                url: "get_teacher",
                data: data,
                success: function (response) {
                    document.getElementById("teacher-option").innerHTML += response;
                }
            })
        }
        else{
            let id = "t" + $(this).val();
            let elements = document.getElementsByClassName(id);

            if (elements != null){
                for (var i = elements.length - 1; i >= 0; --i) {
                    elements[i].innerHTML = "";
                    elements[i].remove();
                }
                
            }
        } 
    });
});