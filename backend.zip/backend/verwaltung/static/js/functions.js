function delPerson(value, type) {
    // Making a prompt to ensure that the user really wants to delete a person
    let test = prompt("Geben sie bitte 'Hallo Welt!' ein und drücken Enter,\nwenn sie diese Person wirklich löschen wollen");
    if (test == "Hallo Welt!"){
        $.ajax({
            type: "POST",
            url: "delete",
            data: { "id": value, "type": type },
            dataType: "json",
            success: function (response) {
                alert(String(response.message));
                location.reload();
            },
            error: function (response) {
                alert(String(response.message));
            }
        });
    }
}

// reuquqest and output a filled out form
function showContent(value, anchor,type){
    $.ajax({
        type: "POST",
        url: "showContent",
        data: {"id": value, "type": type},
        success: function (response) {
            console.log(anchor);
            document.getElementById(anchor).innerHTML = response;
        },
        error: function (response) {
            alert("ERROR: Sending request failed :(");
        }
    })
}