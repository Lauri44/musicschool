var currentSelection;

// function to make request to populate #student-list when the site has finished loading
// and add a click event to all loaded contnent via a delegate
$(document).ready(function(){
    $.ajax({
        type:"GET",
        url:"getStudentContent",
        success: function (response){
            response.forEach(student => {
                $('#student-list').append(
                    `<li class="student-list-item">
                        <p>ID: &nbsp ${student["id"]} &nbsp | &nbsp ${student["vorname"]} &nbsp ${student["nachname"]}</p>
                        <div>
                            <button class="btn show" id="show" value="${student["id"]}">Show</button>                         
                            <button class="btn del" id="del" value="${student["id"]}">Delete</button>
                        </div>
                    </li>`
                )
            });
        },
        error: function(){
            alert("ERROR: Sending request failed :(");
        } 
    });


    const selection = $('#student-list');
    selection.on("click", ".btn", function (event) {
        switch ($(this)[0].id) {
            case "show":
                showContent($(this).val(), "student-info", "s");
                break;
            case "del":
                delPerson($(this).val(), "s");
                break; 
        }
    });

    // just a function to outline selected items
    selection.on("click", ".student-list-item", function (event) {
        if (currentSelection){
            currentSelection.css("border-color", "transparent");
        }
        $(this).css("border-color", "red");
        currentSelection = $(this);
    });
});








