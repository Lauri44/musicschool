const data = document.currentScript.dataset;

// Some logic to make a dynamic graph depending on the count of students and teachers in the database
$(document).ready(function () {
    const send = data.scount;
    const lend = data.lcount;
    let start = 0;
    let speed = 100;

    let sprogressbar = document.getElementById("scount");
    let lprogressbar = document.getElementById("lcount");
    let sprogressvalue = document.getElementById("scount-value");
    let lprogressvalue = document.getElementById("lcount-value");

    let progress = setInterval(() => {
        start++;
        if (start <= send) {
            sprogressvalue.textContent = `${start}`;
            sprogressbar.style.background = `conic-gradient(rgb(212, 0, 255) ${start * 3.6}deg, rgb(71, 71, 71) 0deg)`;
        }

        if (start <= lend) {
            lprogressvalue.textContent = `${start}`;
            lprogressbar.style.background = `conic-gradient(rgb(212, 0, 255) ${start * 36}deg, rgb(71, 71, 71) 0deg)`;
        }

        if (start >= send && start >= lend) {
            clearInterval();
        }

    }, speed)

});