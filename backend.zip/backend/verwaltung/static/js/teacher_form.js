$(document).ready(function () {
    // adds event to get the form for adding new students
    $(".add").on("click", function () {
        $.ajax({
            type: "POST",
            url: "get_form",
            data: { "type": "t" },
            success: function (response) {
                document.getElementById("student-info").innerHTML = response;
            },
            error: function () {
                alert("ERROR: Sending request failed :(");
            }
        })
    });

    // Collecting and turning all the data from the form in to a Json format
    // and sending an ajax request
    $("#student-info").on("click", "#submit", function () {
        var formData = {};

        $(".form-item-group .form-item input, .form-item-group .form-item select").each(function () {
            var fieldName = $(this).attr("name");
            var fieldValue = $(this).val();

            // Sorting out uncheckted check boxes
            if ($(this).is(":checkbox")) {

                if ($(this).is(":checked")) {

                    if (!formData[fieldName]) {
                        formData[fieldName] = [];
                        console.log(fieldName);
                    }
                    formData[fieldName].push(fieldValue);
                    console.log(fieldValue);
                }


            } else {
                // assign the value directly
                formData[fieldName] = fieldValue;
            }
        }
        );

        $.ajax({
            type: "POST",
            url: "addTeacher",
            data: formData,
            dataType: "json",
            success: function (response) {
                alert(String(response.message));
                if (response.success) {
                    location.reload()
                }
            },
            error: function (response) {
                alert("ERROR: Sending request failed :(");
            }
        });
    });
});