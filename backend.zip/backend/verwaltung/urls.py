from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("home", views.home, name="home"),
    path("student", views.student, name="student" ),
    path("getStudentContent", views.getStudentContent),
    path("get_form", views.get_from),
    path("get_teacher", views.get_teacher),
    path("addStudent", views.addStudent),
    path("delete", views.delete),
    path("teacher", views.teacher),
    path("getTeacherContent", views.getTeacherContent),
    path("addTeacher", views.addTeacher),
    path("showContent", views.showContent)
]+static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)