from django.shortcuts import render
from django.template.loader import render_to_string
from django.http import JsonResponse, HttpResponse
from .models import Schueler, Lehrer, Instrument, Ort, Unterrichtet, Lehrt
import re

# Create your views here.

def home(request):
    scount = Schueler.objects.count()
    lcount = Lehrer.objects.count()

    return render(
        request,
        "index.html", 
        {
            "scount": scount, 
            "lcount": lcount
        })

# returns all students in the database
def getStudentContent(request):
    if request.method == "GET":
        students = []
        for student in Schueler.objects.all():
            students.append({
                "id": student.schuelerid,
                "vorname": student.vorname,
                "nachname": student.nachname
            })

        return JsonResponse(students, safe=False)

def student(request):
    return render(request, "student.html")

# returns either the form for students(s) or teachers(t)
def get_from(reuqest):
    if reuqest.method == "POST":
        instrumente = Instrument.objects.all()
        orte = Ort.objects.all().order_by("plz")

        if reuqest.POST["type"] == "s":
            return HttpResponse(
                render_to_string("addStudent.html", {
                    "instrumente": instrumente,
                    "orte": orte
                })
            )
        elif reuqest.POST["type"] == "t":
            return HttpResponse(
                render_to_string("addTeacher.html", {
                    "instrumente": instrumente
                })
            )

# returns list of teachers in form of html for the addStudent form
# depending on what instruments the user selected
def get_teacher(request):
    if request.method == "POST":
        data = request.POST
        instrument = Instrument.objects.get(instrumentid=data["id"])
        lehrer = Lehrer.objects.filter(lehrt__instrumentid=data["id"])
        return HttpResponse(render_to_string("teacherSelection.html", {
            "lehrer": lehrer,
            "id": data["id"],
            "instrument": instrument.bezeichnung
        }))


def addStudent(request):
    if request.method == "POST":
        data = request.POST
        print(data)

        # Checking the minimum amount of validity of the contnet
        if not data["anrede"] in ("Herr", "Frau", "Divers"):
            return JsonResponse({'success': False, "message": "You havn't selected a title!"})

        if not re.match(r"^[a-zA-Z\s]+$", data["vorname"]):
            print(data["vorname"])
            return JsonResponse({'success': False, "message": "There was an error with the first name!"})
        
        if not re.match(r"^[a-zA-Z\s]+$", data["nachname"]):
            return JsonResponse({'success': False, "message": "There was an error with the second name!"})

        if not re.match(r"^[0-9]+$", data["telefon"]):
            return JsonResponse({'success': False, "message": "There was an error with the phone number!"})
        
        if not re.match(r"^[a-zA-Z0-9\s]+$", data["adresse"]):
            return JsonResponse({'success': False, "message": "There was an error with the adress!"})
        
        if not "instrument[]" in data.keys():
            return JsonResponse({'success': False, "message": "You havn't selected a instrument!"})

        if not "lehrer[]" in data.keys():
            return JsonResponse({'success': False, "message": "You havn't selected a teacher!"})
        
        orte = []
        for ort in Ort.objects.all():
            orte.append(ort.plz)

        if not data["plz"] in orte:
            return JsonResponse({'success': False, "message": "You havn't selected a place!"})


        # Adding the student and every related information to the database
        schueler = Schueler(
            vorname=data["vorname"], 
            nachname=data["nachname"], 
            telefon=data["telefon"],
            e_mail=data["mail"],
            adresse=data["adresse"],
            plz=Ort.objects.get(plz=data["plz"])
        )
        schueler.save()

        # dataContent contains the lehrerID and instrumentID
        dataContent = data["lehrer[]"]

        lehrerid = None
        insturmentid = None
    
        if type(dataContent) is str:
            lehrerid, insturmentid = dataContent.split("|")

            unterrichtet = Unterrichtet(
                schuelerid=Schueler.objects.get(schuelerid=schueler.schuelerid),
                lehrerid=Lehrer.objects.get(lehrerid=lehrerid),
                instrumentid=Instrument.objects.get(instrumentid=insturmentid)
            )
            unterrichtet.save()
        else:
            for content in dataContent:
                lehrerid, insturmentid = content.split("|")
    
                unterrichtet = Unterrichtet(
                    schuelerid=Schueler.objects.get(schuelerid=schueler.schuelerid),
                    lehrerid=Lehrer.objects.get(lehrerid=lehrerid),
                    instrumentid=Instrument.objects.get(instrumentid=insturmentid)
                ) 
                unterrichtet.save()
            

        return JsonResponse({'success': True, "message": "Der neue Schüler wurde Hinzugefügt!"})

    return JsonResponse({'success': False, "message": "Sie haben nichts eingeben!"})

def delete(request):
    if request.method == "POST":
        data = request.POST

        if data["type"] == "s":
            for foo in Unterrichtet.objects.filter(schuelerid=data["id"]):
                foo.delete()

            Schueler.objects.get(schuelerid=data["id"]).delete()
    
            return JsonResponse({"success": True, "message": "Schüler wurde gelöscht"})
        elif data["type"] == "t":
            for foo in Unterrichtet.objects.filter(lehrerid=data["id"]):
                foo.delete()

            for foo in Lehrt.objects.filter(lehrerid=data["id"]):
                foo.delete()

            Lehrer.objects.get(lehrerid=data["id"]).delete()

            return JsonResponse({"success": True, "message": "Lehrer wurde gelöscht"})

    return JsonResponse({"success": False, "message": "Niemand wurde gelöscht"})

def teacher(request):
    return render(request, "teacher.html")

# reutrns all teachers in the database
def getTeacherContent(request):
    if request.method == "GET":
        teachers = []
        for teacher in Lehrer.objects.all():
            teachers.append({
                "id": teacher.lehrerid,
                "vorname": teacher.vorname,
                "nachname": teacher.nachname
            })
    return JsonResponse(teachers, safe=False)

def addTeacher(request):
    if request.method == "POST":
        data = request.POST
        print(data)

        # Checking the minimum amount of validity of the contnet
        if not data["anrede"] in ("Herr", "Frau", "Divers"):
            return JsonResponse({'success': False, "message": "You havn't selected a title!"})

        if not re.match(r"^[a-zA-Z\s]+$", data["vorname"]):
            return JsonResponse({'success': False, "message": "There was an error with the first name!"})

        if not re.match(r"^[a-zA-Z\s]+$", data["nachname"]):
            return JsonResponse({'success': False, "message": "There was an error with the second name!"})

        if not re.match(r"^[0-9]+$", data["telefon"]):
            return JsonResponse({'success': False, "message": "There was an error with the phone number!"})

        if not re.match(r"^[A-Z]{2}[0-9]+$", data["iban"]):
            return JsonResponse({'success': False, "message": "Fehler bei der eingabe der IBAN!"})

        if not "instrument[]" in data.keys():
            return JsonResponse({'success': False, "message": "Sie haben kein instrument ausgewählt!"})

        lehrer = Lehrer(
            vorname=data["vorname"],
            nachname=data["nachname"],
            telefon=data["telefon"],
            e_mail=data["mail"],
            iban=data["iban"]
        )
        lehrer.save()

        for foo in data["instrument[]"]:
            lehrt = Lehrt(
                lehrerid=lehrer,
                instrumentid=Instrument.objects.get(instrumentid=foo)
            )
            lehrt.save()
        
        return JsonResponse({'success': True, "message": "Neuer Lehrer wurde hinzugefügt!"})


# This view reutrns a filled out form with data form a student or a teachers
def showContent(request):
    if request.method == "POST":
        data = request.POST
        show = True

        if data["type"] == "s":
            teachers = Lehrer.objects.filter(unterrichtet__schuelerid=data["id"])
            student = Schueler.objects.get(schuelerid=data["id"])
            #tinstrumente = Instrument.objects.all()
            instrumente = Instrument.objects.filter(unterrichtet__schuelerid=student.schuelerid)
            #tteacher = Lehrer.objects.filter(unterrichtet__instrument__in=instrumente)
            
            orte = Ort.objects.all()

            return HttpResponse(
                render_to_string("addStudent.html", {
                    "show": show,
                    "teachers": teachers,
                    "instrumente": instrumente,
                    "student": student,
                    "orte": orte,
                })
            )
        if data["type"] == "t":
            teacher = Lehrer.objects.get(lehrerid=data["id"])
            students = Schueler.objects.filter(unterrichtet__lehrerid=data["id"])
            #tinstrumente = Instrument.objects.all()
            instrumente = Instrument.objects.filter(lehrt__lehrerid=data["id"])
            
            
            return HttpResponse(
                render_to_string("addTeacher.html", {
                    "show": show,
                    "teacher": teacher,
                    "instrumente": instrumente,
                    "students": students 
                })
            )
