# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Instrument(models.Model):
    instrumentid = models.AutoField(db_column='instrumentID', primary_key=True)  # Field name made lowercase.
    bezeichnung = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'instrument'


class Lehrer(models.Model):
    lehrerid = models.AutoField(db_column='lehrerID', primary_key=True)  # Field name made lowercase.
    vorname = models.CharField(max_length=255)
    nachname = models.CharField(max_length=255)
    telefon = models.CharField(max_length=255)
    e_mail = models.CharField(max_length=255)
    iban = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'lehrer'


class Lehrt(models.Model):
    lehrerid = models.OneToOneField(Lehrer, models.DO_NOTHING, db_column='lehrerID', primary_key=True)  # Field name made lowercase. The composite primary key (lehrerID, instrumentID) found, that is not supported. The first column is selected.
    instrumentid = models.ForeignKey(Instrument, models.DO_NOTHING, db_column='instrumentID')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lehrt'
        unique_together = (('lehrerid', 'instrumentid'),)


class Ort(models.Model):
    plz = models.CharField(db_column='PLZ', primary_key=True, max_length=255)  # Field name made lowercase.
    ort = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'ort'


class Schueler(models.Model):
    schuelerid = models.AutoField(db_column='schuelerID', primary_key=True)  # Field name made lowercase.
    vorname = models.CharField(max_length=255)
    nachname = models.CharField(max_length=255)
    telefon = models.CharField(max_length=255)
    e_mail = models.CharField(max_length=255)
    adresse = models.CharField(max_length=255)
    plz = models.ForeignKey(Ort, models.DO_NOTHING, db_column='PLZ')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'schueler'


class Unterrichtet(models.Model):
    schuelerid = models.OneToOneField(Schueler, models.DO_NOTHING, db_column='schuelerID', primary_key=True)  # Field name made lowercase. The composite primary key (schuelerID, lehrerID) found, that is not supported. The first column is selected.
    lehrerid = models.ForeignKey(Lehrer, models.DO_NOTHING, db_column='lehrerID')  # Field name made lowercase.
    instrumentid = models.ForeignKey(Instrument, models.DO_NOTHING, db_column='instrumentID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'unterrichtet'
        unique_together = (('schuelerid', 'lehrerid'),)
